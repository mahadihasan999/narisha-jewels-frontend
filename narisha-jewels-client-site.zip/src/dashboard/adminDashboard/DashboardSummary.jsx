import React from "react";

const DashboardSummary = () => {
  return (
    <div>
      <h1> THis is dashboard</h1>
    </div>
  );
};

export default DashboardSummary;
